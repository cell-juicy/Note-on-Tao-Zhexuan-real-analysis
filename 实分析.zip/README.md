# Notes-on-Tao-Zhexuan-real-analysis
Here are some of my personal notes on Tao Zhexuan Real Analysis, updated from time to time, I will only provide Chinese md files, if you have any questions or think there are errors in it, you can contact me to discuss.

Also, the documentation is edited using `Typora`, some of the interlinear formulas and colors can no longer be displayed in `GitHub`, you can download the documentation and view it in `Typora`. The project provides a zip download of the entire folder, please do not move the files relative to each other (some note skipping is required)

At present, the progress is updated, notes to section 5.3 and exercises to section 3.6。

---

这里是我对《陶哲轩实分析》的一些个人笔记，不定期更新，本人只会提供中文md文档，如果你有任何的疑问或者认为里面存在错误的地方，可以联系本人讨论。

另外，文档使用`Typora`编辑，部分行间公式与颜色不能再`GitHub`中显示，您可以下载文档后在`Typora`中查看。项目提供整个文件夹的压缩包下载，请不要乱动文件相对位置（有些笔记跳转需要）

目前更新进度，笔记到5.4节，习题到3.6节。